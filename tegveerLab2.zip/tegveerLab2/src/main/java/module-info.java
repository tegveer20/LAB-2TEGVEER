module com.example.tegveerlab2 {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens com.example.tegveerlab2 to javafx.fxml;
    exports com.example.tegveerlab2;
}