package com.example.tegveerlab2;

public class customer{

}
